"""Brain games."""
